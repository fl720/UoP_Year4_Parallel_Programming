import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.*;

public class LUBench {

    //  Random matrix/vector 
    static double[][] randomMatrix(int n, long seed) {
        Random rand = new Random(seed);
        double[][] A = new double[n][n];
        for (int i = 0; i < n; i++) {
            double[] row = A[i];
            for (int j = 0; j < n; j++) row[j] = rand.nextDouble();
            row[i] += n; 
        }
        return A;
    }

    static double[] randomVector(int n, long seed) {
        Random rand = new Random(seed);
        double[] b = new double[n];
        for (int i = 0; i < n; i++) b[i] = rand.nextDouble();
        return b;
    }

    static double[][] copyMatrix(double[][] A) {
        int n = A.length;
        double[][] C = new double[n][n];
        for (int i = 0; i < n; i++) System.arraycopy(A[i], 0, C[i], 0, n);
        return C;
    }

    //  Correctness 
    static double[] matVec(double[][] A, double[] x) {
        int n = A.length;
        double[] y = new double[n];
        for (int i = 0; i < n; i++) {
            double sum = 0.0;
            double[] Ai = A[i];
            for (int j = 0; j < n; j++) sum += Ai[j] * x[j];
            y[i] = sum;
        }
        return y;
    }

    static double maxAbsDiff(double[] a, double[] b) {
        double m = 0.0;
        for (int i = 0; i < a.length; i++) m = Math.max(m, Math.abs(a[i] - b[i]));
        return m;
    }

    // Sequential LU 
    static void luDecomposeInPlace(double[][] LU) {
        int n = LU.length;
        for (int k = 0; k < n; k++) {
            double pivot = LU[k][k];
            if (Math.abs(pivot) < 1e-12) {
                throw new ArithmeticException("Zero/small pivot at k=" + k + " (no pivoting).");
            }

            for (int i = k + 1; i < n; i++) LU[i][k] /= pivot;

            double[] LUk = LU[k];
            for (int i = k + 1; i < n; i++) {
                double lik = LU[i][k];
                double[] LUi = LU[i];
                for (int j = k + 1; j < n; j++) {
                    LUi[j] -= lik * LUk[j];
                }
            }
        }
    }

    // Thread-pool LU (parallel trailing update)
    static void luDecomposeInPlaceParallelPool(double[][] LU, int numThreads) throws InterruptedException {
        int n = LU.length;
        numThreads = Math.max(1, Math.min(numThreads, n));

        ExecutorService pool = Executors.newFixedThreadPool(numThreads);
        try {
            for (int k = 0; k < n; k++) {
                double pivot = LU[k][k];
                if (Math.abs(pivot) < 1e-12) {
                    throw new ArithmeticException("Zero/small pivot at k=" + k + " (no pivoting).");
                }

                for (int i = k + 1; i < n; i++) LU[i][k] /= pivot;

                
                final int kk = k;
                final double[] LUk = LU[kk];

                int startRow = kk + 1;
                int rows = n - startRow;
                if (rows <= 0) continue;

                int rowsPerTask = (rows + numThreads - 1) / numThreads;
                List<Callable<Void>> tasks = new ArrayList<>();

                for (int t = 0; t < numThreads; t++) {
                    final int from = startRow + t * rowsPerTask;
                    final int to = Math.min(n, from + rowsPerTask);
                    if (from >= to) break;

                    tasks.add(() -> {
                        for (int i = from; i < to; i++) {
                            double lik = LU[i][kk];
                            double[] LUi = LU[i];
                            for (int j = kk + 1; j < n; j++) {
                                LUi[j] -= lik * LUk[j];
                            }
                        }
                        return null;
                    });
                }

                pool.invokeAll(tasks);
            }
        } finally {
            pool.shutdown();
            pool.awaitTermination(1, TimeUnit.MINUTES);
        }
    }

    static double[] solveWithLU(double[][] LU, double[] b) {
        int n = LU.length;
        double[] y = new double[n];
        double[] x = new double[n];

        // Forward: Ly=b  
        for (int i = 0; i < n; i++) {
            double sum = b[i];
            for (int j = 0; j < i; j++) sum -= LU[i][j] * y[j];
            y[i] = sum;
        }

        // Backward: Ux=y
        for (int i = n - 1; i >= 0; i--) {
            double sum = y[i];
            for (int j = i + 1; j < n; j++) sum -= LU[i][j] * x[j];
            double pivot = LU[i][i];
            if (Math.abs(pivot) < 1e-12) throw new ArithmeticException("Zero/small pivot in U at i=" + i);
            x[i] = sum / pivot;
        }

        return x;
    }

    //  main 
    public static void main(String[] args) throws Exception {
        int N = (args.length >= 1) ? Integer.parseInt(args[0]) : 2048;
        int threads = (args.length >= 2) ? Integer.parseInt(args[1]) : 1;

        int warmups = 2;
        int trials = 3;

        System.out.println("N = " + N);
        System.out.println("Threads = " + threads);

        double[][] A = randomMatrix(N, 123);
        double[] b = randomVector(N, 456);

        // Warmup
        for (int w = 0; w < warmups; w++) {
            double[][] LU = copyMatrix(A);
            if (threads <= 1) luDecomposeInPlace(LU);
            else luDecomposeInPlaceParallelPool(LU, threads);
            double[] x = solveWithLU(LU, b);
            if (x[0] == -1) System.out.print("");
        }

        // Trials
        for (int t = 0; t < trials; t++) {
            double[][] LU = copyMatrix(A);

            long t0 = System.nanoTime();
            if (threads <= 1) luDecomposeInPlace(LU);
            else luDecomposeInPlaceParallelPool(LU, threads);
            double[] x = solveWithLU(LU, b);
            long t1 = System.nanoTime();

            double ms = (t1 - t0) / 1_000_000.0;
            double err = maxAbsDiff(matVec(A, x), b);

            System.out.println("Run " + (t + 1) + ": " + ms + " ms, max|Ax-b|=" + err);
        }

    }
}
