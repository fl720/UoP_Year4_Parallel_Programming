import mpi.*;
import java.util.*;

public class MPJMatMul {

    final static int N = 5120;

    static double[][] A;
    static double[][] B;
    static double[][] C;

    static double[][] localA;
    static double[][] localC;

    public static void main(String args[]) throws Exception {

        MPI.Init(args);

        int me = MPI.COMM_WORLD.Rank();
        int P  = MPI.COMM_WORLD.Size();

        int Bsize = N / P;

        if(me == 0) {
            A = randomMatrix();
            B = randomMatrix();
            C = new double[N][N];
        }

        localA = new double[Bsize][N];
        localC = new double[Bsize][N];

        MPI.COMM_WORLD.Scatter(A, 0, Bsize, MPI.OBJECT,
                               localA, 0, Bsize, MPI.OBJECT, 0);

        if(me != 0) B = new double[N][N];
        MPI.COMM_WORLD.Bcast(B, 0, N, MPI.OBJECT, 0);

        long startTime = System.currentTimeMillis();

        for(int i = 0; i < Bsize; i++) {
            for(int j = 0; j < N; j++) {
                for(int k = 0; k < N; k++) {
                    localC[i][j] += localA[i][k] * B[k][j];
                }
            }
        }

        MPI.COMM_WORLD.Gather(localC, 0, Bsize, MPI.OBJECT,
                              C, 0, Bsize, MPI.OBJECT, 0);

        long endTime = System.currentTimeMillis();

        if(me == 0) {
            System.out.println("MPJ Matrix Multiplication Completed in " +
                               (endTime - startTime) + " ms");
        }

        MPI.Finalize();
    }

    static double[][] randomMatrix() {
        Random r = new Random(123);
        double[][] m = new double[N][N];
        for(int i=0;i<N;i++)
            for(int j=0;j<N;j++)
                m[i][j] = r.nextDouble();
        return m;
    }
}

