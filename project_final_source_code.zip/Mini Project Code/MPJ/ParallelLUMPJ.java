import mpi.*;
import java.util.Random;

public class ParallelLUMPJ {

    static int N = 5120;

    public static void main(String[] args) throws Exception {

        MPI.Init(args);

        int rank = MPI.COMM_WORLD.Rank();
        int size = MPI.COMM_WORLD.Size();

        int rowsPerProcess = N / size;

        double[][] localA = new double[rowsPerProcess][N];
        double[][] L = new double[rowsPerProcess][N];
        double[][] U = new double[N][N];

        double[] flatA = null;
        double[] localFlatA = new double[rowsPerProcess * N];

        if (rank == 0) {
            flatA = new double[N * N];
            Random rand = new Random();

            for (int i = 0; i < N; i++)
                for (int j = 0; j < N; j++)
                    flatA[i * N + j] = rand.nextDouble() + 1.0;
        }

        MPI.COMM_WORLD.Scatter(
                flatA,
                0,
                rowsPerProcess * N,
                MPI.DOUBLE,
                localFlatA,
                0,
                rowsPerProcess * N,
                MPI.DOUBLE,
                0
        );

        for (int i = 0; i < rowsPerProcess; i++)
            for (int j = 0; j < N; j++)
                localA[i][j] = localFlatA[i * N + j];

        MPI.COMM_WORLD.Barrier();
        long start = System.currentTimeMillis();

        for (int k = 0; k < N; k++) {

            int owner = k / rowsPerProcess;

            if (rank == owner) {
                int localRow = k % rowsPerProcess;
                for (int j = k; j < N; j++)
                    U[k][j] = localA[localRow][j];
            }

            MPI.COMM_WORLD.Bcast(U[k], 0, N, MPI.DOUBLE, owner);

            for (int i = 0; i < rowsPerProcess; i++) {
                int globalRow = rank * rowsPerProcess + i;
                if (globalRow > k) {
                    L[i][k] = localA[i][k] / U[k][k];
                    for (int j = k; j < N; j++)
                        localA[i][j] -= L[i][k] * U[k][j];
                }
            }

            MPI.COMM_WORLD.Barrier();
        }

        long end = System.currentTimeMillis();

        if (rank == 0)
            System.out.println("Parallel LU completed in " + (end - start) + " ms");

        MPI.Finalize();
    }
}

