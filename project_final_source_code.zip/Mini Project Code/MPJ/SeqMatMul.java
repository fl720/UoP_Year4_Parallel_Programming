import mpi.*;
import java.util.*;

public class SeqMatMul {

    final static int N = 4096;

    public static void main(String args[]) throws Exception {

        MPI.Init(args);

        int me = MPI.COMM_WORLD.Rank();

        if(me == 0){

            double[][] A = randomMatrix();
            double[][] B = randomMatrix();
            double[][] C = new double[N][N];

            long startTime = System.currentTimeMillis();

            for(int i = 0; i < N; i++){
                for(int j = 0; j < N; j++){
                    for(int k = 0; k < N; k++){
                        C[i][j] += A[i][k] * B[k][j];
                    }
                }
            }

            long endTime = System.currentTimeMillis();

            System.out.println("Sequential Matrix Multiplication Completed in " +
                               (endTime - startTime) + " ms");

        }

        MPI.Finalize();
    }

    static double[][] randomMatrix(){
        Random r = new Random(123);
        double[][] m = new double[N][N];
        for(int i=0;i<N;i++)
            for(int j=0;j<N;j++)
                m[i][j] = r.nextDouble();
        return m;
    }
}

