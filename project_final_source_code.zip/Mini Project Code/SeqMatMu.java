import java.util.Random;

public class SeqMatMu {

    // Random matrix 
    static double[][] randomMatrix(int n, long seed) {
        Random rand = new Random(seed);
        double[][] M = new double[n][n];
        for (int i = 0; i < n; i++) {
            double[] row = M[i];
            for (int j = 0; j < n; j++) {
                row[j] = rand.nextDouble();
            }
        }
        return M;
    }

    // Transpose 
    static double[][] transpose(double[][] M) {
        int n = M.length;
        double[][] T = new double[n][n];
        for (int i = 0; i < n; i++) {
            double[] Mi = M[i];
            for (int j = 0; j < n; j++) {
                T[j][i] = Mi[j];
            }
        }
        return T;
    }

    //  Sequential multiply
    static double[][] multiplySequentialBt(double[][] A, double[][] Bt) {
        int n = A.length;
        double[][] C = new double[n][n];

        for (int i = 0; i < n; i++) {
            double[] Ai = A[i];
            double[] Ci = C[i];

            for (int j = 0; j < n; j++) {
                double[] Btj = Bt[j];
                double sum = 0.0;

                for (int k = 0; k < n; k++) {
                    sum += Ai[k] * Btj[k];
                }
                Ci[j] = sum;
            }
        }
        return C;
    }

    // Parallel multiply
    static double[][] multiplyParallelBt(double[][] A, double[][] Bt, int numThreads) throws InterruptedException {
        int n = A.length;
        double[][] C = new double[n][n];

        numThreads = Math.max(1, Math.min(numThreads, n)); // <= rows
        Thread[] workers = new Thread[numThreads];

        int rowsPerThread = (n + numThreads - 1) / numThreads;

        for (int t = 0; t < numThreads; t++) {
            final int start = t * rowsPerThread;
            final int end = Math.min(n, start + rowsPerThread);

            workers[t] = new Thread(() -> {
                for (int i = start; i < end; i++) {
                    double[] Ai = A[i];
                    double[] Ci = C[i];

                    for (int j = 0; j < n; j++) {
                        double[] Btj = Bt[j];
                        double sum = 0.0;

                        for (int k = 0; k < n; k++) {
                            sum += Ai[k] * Btj[k];
                        }
                        Ci[j] = sum;
                    }
                }
            });

            workers[t].start();
        }

        for (Thread th : workers) th.join();
        return C;
    }

    // Correctness check
    static void assertSame(double[][] X, double[][] Y, double eps) {
        int n = X.length;
        for (int i = 0; i < n; i++) {
            double[] Xi = X[i];
            double[] Yi = Y[i];
            for (int j = 0; j < n; j++) {
                double a = Xi[j];
                double b = Yi[j];
                double diff = Math.abs(a - b);

                double scale = Math.max(1.0, Math.max(Math.abs(a), Math.abs(b)));
                if (diff > eps * scale) {
                    throw new AssertionError("Mismatch at (" + i + "," + j + "): " + a + " vs " + b);
                }
            }
        }
    }

    // Checksum 
    static double checksum(double[][] C) {
        double s = 0.0;
        int n = C.length;
        for (int i = 0; i < n; i++) {
            double[] Ci = C[i];
            for (int j = 0; j < n; j++) {
                s += Ci[j];
            }
        }
        return s;
    }

    //  Main 
    public static void main(String[] args) throws Exception {
        int N = (args.length >= 1) ? Integer.parseInt(args[0]) : 1024;
        int threads = (args.length >= 2) ? Integer.parseInt(args[1]) : Runtime.getRuntime().availableProcessors();
        int warmups = 2;
        int trials = 5;

        System.out.println("N = " + N);
        System.out.println("Threads = " + threads);

        double[][] A = randomMatrix(N, 123);
        double[][] B = randomMatrix(N, 456);
        double[][] Bt = transpose(B);

        // Warmup
        for (int w = 0; w < warmups; w++) {
            multiplySequentialBt(A, Bt);
            multiplyParallelBt(A, Bt, threads);
        }

        // Sequential trials
        System.out.println("\nSequential runs (ms):");
        for (int t = 0; t < trials; t++) {
            long t0 = System.nanoTime();
            double[][] tmp = multiplySequentialBt(A, Bt);
            long t1 = System.nanoTime();
            double ms = (t1 - t0) / 1_000_000.0;
            //System.out.println("  Run " + (t + 1) + ": " + ms);

            if (tmp[0][0] == -1) System.out.print("");
        }

        // Parallel trials 
        System.out.println("\nParallel runs (ms):");
        for (int t = 0; t < trials; t++) {
            long t0 = System.nanoTime();
            double[][] tmp = multiplyParallelBt(A, Bt, threads);
            long t1 = System.nanoTime();
            double ms = (t1 - t0) / 1_000_000.0;
            System.out.println("  Run " + (t + 1) + ": " + ms);

            if (tmp[0][0] == -1) System.out.print("");
    
        }

        double[][] Cseq = multiplySequentialBt(A, Bt);
        double[][] Cpar = multiplyParallelBt(A, Bt, threads);
        assertSame(Cseq, Cpar, 1e-9);

        System.out.println("\nCorrectness: PASS");
        System.out.println("Checksum: " + checksum(Cpar));
    }
}
